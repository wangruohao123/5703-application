//
//  ClassCell.swift
//  KINDER FOOD FINDER
//
//  Created by Boning He on 2019/04/09.
//  Copyright © 2019 KINDER FOOD FINDER. All rights reserved.
//

import UIKit

class ClassCell: UITableViewCell {

    @IBOutlet weak var classLabel: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
