//
//  MapVC.swift
//  KINDER FOOD FINDER
//
//  Created by Boning He on 2019/04/12.
//  Copyright © 2019 KINDER FOOD FINDER. All rights reserved.
//

import UIKit
import MapKit

class MapVC: UIViewController ,CLLocationManagerDelegate{
    var locations: [Location] = []
    var locationManager = CLLocationManager()
    var userLocation = CLLocationCoordinate2D()
    
    @IBOutlet weak var locationInfo: UITextView!
    @IBOutlet weak var mapView: MKMapView!
    var Rawdata : Rawdata!
    func loadJson() {
        let coder = JSONDecoder()
        
        do{
            let url = Bundle.main.url(forResource: "locations", withExtension: "json")!
            let data = try Data(contentsOf: url)
            locations = try coder.decode([Location].self, from: data)
            
        }
        catch{
            print(error)
            
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        loadJson()
        createoverAnnotations()
        mapView.showsScale = true
        mapView.showsCompass = true
        mapView.showsUserLocation = true
        mapView.showsBuildings = true
        mapView.showsTraffic = true
        locationManager.delegate = self
        locationManager.desiredAccuracy = kCLLocationAccuracyBest
        locationManager.requestWhenInUseAuthorization()
        locationManager.startUpdatingLocation()
        locationInfo.text = Rawdata.availability
}
    
    // locate user
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        if let coord = manager.location?.coordinate {
            let center = CLLocationCoordinate2D(latitude: coord.latitude, longitude: coord.longitude)
            userLocation = center
            let region = MKCoordinateRegion(center: userLocation, span: MKCoordinateSpan(latitudeDelta: 0.02, longitudeDelta: 0.02))
            mapView.setRegion(region, animated: true)
        }
    }
    
    //load all data in JSON and mark the map
    func createoverAnnotations() -> Void {
        for location : Location in locations{
            let annotations = MKPointAnnotation()
            annotations.title = location.location_information
            let lat = (location.location_latitude as NSString).doubleValue
            let long = (location.location_longitude as NSString).doubleValue
            annotations.coordinate = CLLocationCoordinate2D(latitude: lat, longitude: long)
            mapView.addAnnotation(annotations)
            
        }
    
    }
    
}

