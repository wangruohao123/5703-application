//
//  Location.swift
//  KINDER FOOD FINDER
//
//  Created by Boning He on 2019/04/13.
//  Copyright © 2019 KINDER FOOD FINDER. All rights reserved.
//

struct Location: Codable {
    var location_information = ""
    var location_longitude = ""
    var location_latitude = ""
    
}
