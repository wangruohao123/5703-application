//
//  ViewController.swift
//  KINDER FOOD FINDER
//
//  Created by Boning He on 2019/03/26.
//  Copyright © 2019 KINDER FOOD FINDER. All rights reserved.
//

import UIKit

class Home: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }


}

