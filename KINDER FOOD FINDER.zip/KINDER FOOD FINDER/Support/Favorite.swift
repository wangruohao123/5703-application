//
//  Favorite.swift
//  KINDER FOOD FINDER
//
//  Created by Boning He on 2019/4/24.
//  Copyright © 2019 KINDER FOOD FINDER. All rights reserved.
//

struct Favorite: Decodable {
    var FIELD6 = false
}
